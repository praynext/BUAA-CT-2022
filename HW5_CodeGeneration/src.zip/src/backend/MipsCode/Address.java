package backend.MipsCode;

public interface Address {
}
