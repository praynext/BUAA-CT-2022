package midend.MidCode;

public interface Operate {
}
