package midend.MidCode;

public interface Operate extends UseVal {
}
