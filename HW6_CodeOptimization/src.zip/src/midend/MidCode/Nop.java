package midend.MidCode;

public class Nop extends MidCode {
    public Nop() {
    }

    @Override
    public String toString() {
        return "NOP";
    }
}
