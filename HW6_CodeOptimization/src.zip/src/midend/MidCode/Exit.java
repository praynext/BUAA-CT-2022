package midend.MidCode;

public class Exit extends MidCode {
    public Exit() {
    }

    @Override
    public String toString() {
        return "EXIT";
    }
}
