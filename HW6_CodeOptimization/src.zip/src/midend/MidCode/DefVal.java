package midend.MidCode;

public interface DefVal {
    Value getDefVal();
}
