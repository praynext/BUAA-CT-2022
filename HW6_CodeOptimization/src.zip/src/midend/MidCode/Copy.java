package midend.MidCode;

import java.util.LinkedList;

public interface Copy {
    LinkedList<Value> getSrc();

    Value getDst();
}
