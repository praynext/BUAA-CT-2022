package backend.MipsCode;

public interface MipsCode {
}
