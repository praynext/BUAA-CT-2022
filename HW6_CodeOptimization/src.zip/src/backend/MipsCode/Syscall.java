package backend.MipsCode;

public class Syscall implements MipsCode {
    @Override
    public String toString() {
        return "syscall";
    }
}
